import PortfolioDesktop from "../components/PortfolioDesktop";

const Root = () => {
  return (
    <div className="w-full relative flex flex-row items-start justify-start leading-[normal] tracking-[normal]">
      <PortfolioDesktop />
    </div>
  );
};

export default Root;
