const Footer = ({ className = "" }) => {
  return (
    <div
      className={`w-[1365px] flex flex-row items-start justify-start py-0 px-[63px] box-border max-w-full text-right text-12xl-5 text-glass font-clash-display mq1350:pl-[31px] mq1350:pr-[31px] mq1350:box-border ${className}`}
    >
      <div
        className="h-[806.2px] flex-1 relative shrink-0 [debug_commit:bf4bc93] max-w-full z-[4] mq800:h-auto mq800:min-h-[806.1999999999998]"
        data-scroll-to="groupContainer"
      >
        <img
          className="absolute top-[0px] left-[0px] w-[643.1px] h-[643px] object-contain"
          alt=""
          src="/group@2x.png"
        />
        <div className="absolute top-[279.2px] left-[15.7px] w-[1223px] flex flex-row items-start justify-start max-w-full z-[1]">
          <div className="flex-1 flex flex-row items-start justify-start max-w-full">
            <div className="flex-1 [backdrop-filter:blur(42px)] rounded-6xl [background:linear-gradient(180deg,_rgba(255,_255,_255,_0.4)_0.55%,_rgba(255,_255,_255,_0))] box-border overflow-hidden flex flex-col items-end justify-start pt-[65px] pb-[45px] pr-[53px] pl-[54px] gap-[67.2px] max-w-full border-[1px] border-solid border-glass">
              <div className="w-[671.3px] flex flex-row items-start justify-end py-0 px-[59px] box-border max-w-full">
                <div className="flex-1 flex flex-row items-start justify-start gap-[42px] max-w-full mq800:flex-wrap">
                  <div className="h-[276.5px] flex-1 flex flex-col items-end justify-start pt-0 px-0 pb-[237.5px] box-border gap-[16.6px] min-w-[190px]">
                    <div className="self-stretch relative font-semibold shrink-0 [debug_commit:bf4bc93] mq450:text-lgi mq800:text-6xl">
                      Professional Links
                    </div>
                    <div className="w-[147.1px] flex flex-col items-start justify-start gap-[24px] shrink-0 [debug_commit:bf4bc93]">
                      <div className="self-stretch relative font-light mq450:text-lgi mq800:text-6xl">
                        LinkedIn
                      </div>
                      <div className="self-stretch relative font-light mq450:text-lgi mq800:text-6xl">
                        Behance
                      </div>
                      <div className="self-stretch relative font-light mq450:text-lgi mq800:text-6xl">
                        Dribbble
                      </div>
                      <div className="self-stretch relative leading-[31.8px] font-light mq450:text-lgi mq450:leading-[19px] mq800:text-6xl mq800:leading-[25px]">
                        Figma
                      </div>
                    </div>
                  </div>
                  <div className="w-[218px] flex flex-col items-end justify-start gap-[16.5px] min-w-[218px] mq800:flex-1">
                    <div className="self-stretch relative font-semibold mq450:text-lgi mq800:text-6xl">
                      Quick Menu
                    </div>
                    <div className="w-[147.1px] flex flex-row items-start justify-start pt-0 px-0 pb-[7.6px] box-border">
                      <div className="flex-1 relative font-light shrink-0 mq450:text-lgi mq800:text-6xl">
                        Home
                      </div>
                    </div>
                    <div className="w-[147.1px] flex flex-col items-start justify-start gap-[24px]">
                      <div className="self-stretch relative font-light mq450:text-lgi mq800:text-6xl">
                        About
                      </div>
                      <div className="self-stretch relative font-light mq450:text-lgi mq800:text-6xl">
                        Work
                      </div>
                      <div className="self-stretch relative leading-[31.8px] font-light mq450:text-lgi mq450:leading-[19px] mq800:text-6xl mq800:leading-[25px]">
                        Contact
                      </div>
                    </div>
                  </div>
                </div>
              </div>
              <footer className="self-stretch flex flex-col items-end justify-start relative gap-[27.4px] max-w-full text-left text-smi-6 text-glass font-clash-display">
                <div className="self-stretch h-[1.6px] relative box-border border-t-[1.6px] border-solid border-glass" />
                <div className="w-[1092.1px] flex flex-row items-start justify-end py-0 px-px box-border max-w-full">
                  <div className="flex-1 flex flex-row items-start justify-between max-w-full gap-[20px] mq800:flex-wrap">
                    <div className="flex flex-col items-start justify-start pt-[11.3px] px-0 pb-0">
                      <div className="relative font-light">
                        @ 2024 Shaun Murphy All Rights Reserved
                      </div>
                    </div>
                    <div className="flex flex-row items-start justify-start gap-[9.6px]">
                      <div className="h-[40.2px] w-[40.2px] relative rounded-[50%] box-border border-[0px] border-solid border-glass" />
                      <div className="h-[40.2px] w-[40.2px] relative rounded-[50%] box-border border-[0px] border-solid border-glass" />
                      <div className="h-[40.2px] w-[40.2px] relative rounded-[50%] box-border border-[0px] border-solid border-glass" />
                    </div>
                  </div>
                </div>
                <img
                  className="w-[26px] h-[21.1px] absolute !m-[0] right-[8.6px] bottom-[9.2px] z-[1]"
                  loading="lazy"
                  alt=""
                  src="/vector.svg"
                />
                <img
                  className="w-[24.2px] h-[24.2px] absolute !m-[0] right-[59.7px] bottom-[7.8px] z-[1]"
                  loading="lazy"
                  alt=""
                  src="/vector-1.svg"
                />
                <img
                  className="w-[18.2px] h-[32.9px] absolute !m-[0] right-[110.7px] bottom-[0.5px] z-[1]"
                  loading="lazy"
                  alt=""
                  src="/vector-2.svg"
                />
              </footer>
            </div>
            <img
              className="self-stretch w-[1223px] relative rounded-6xl max-h-full object-cover hidden mix-blend-overlay min-h-[527px] max-w-full"
              alt=""
              src="/rectangle@2x.png"
            />
          </div>
        </div>
        <img
          className="absolute top-[130.2px] left-[26.7px] w-[589px] h-[589px] object-contain z-[2]"
          loading="lazy"
          alt=""
          src="/2f440dec5d828b72087f9cf70bf66ce4sticker-1@2x.png"
        />
      </div>
    </div>
  );
};

Footer.propTypes = {
  className: PropTypes.string,
};

export default Footer;
