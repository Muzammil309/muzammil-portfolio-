import { Button } from "@mui/material";

const CompanyItemsTwo = ({ className = "" }) => {
  return (
    <div
      className={`w-[1410px] overflow-x-auto flex flex-row items-start justify-start gap-[32px] shrink-0 [debug_commit:bf4bc93] max-w-full z-[4] text-left text-28xl-2 text-glass font-clash-display mq800:gap-[16px] ${className}`}
    >
      <div className="rounded-[56.04px] [background:linear-gradient(174.61deg,_rgba(255,_255,_255,_0.11),_rgba(58,_58,_58,_0.11))] overflow-hidden shrink-0 flex flex-row items-start justify-start py-[18px] px-3 whitespace-nowrap border-[1.1px] border-solid border-darkgray-100">
        <div className="relative font-light">Union Living</div>
      </div>
      <div className="rounded-[56.04px] [background:linear-gradient(174.61deg,_rgba(255,_255,_255,_0.11),_rgba(58,_58,_58,_0.11))] overflow-hidden shrink-0 flex flex-row items-start justify-start py-[18px] pr-[38px] pl-10 border-[1.1px] border-solid border-darkgray-100">
        <div className="relative font-light mq450:text-9xl mq800:text-19xl">
          Fiverr
        </div>
      </div>
      <Button
        className="h-[96.9px] w-[298.1px]"
        disableElevation={true}
        variant="contained"
        sx={{
          textTransform: "none",
          color: "#fff",
          fontSize: "47.2",
          background:
            "linear-gradient(174.61deg, rgba(255, 255, 255, 0.11), rgba(58, 58, 58, 0.11))",
          border: "#a9a9a9 solid 1.1px",
          borderRadius: "56.03589630126953px",
          "&:hover": {
            background:
              "linear-gradient(174.61deg, rgba(255, 255, 255, 0.11), rgba(58, 58, 58, 0.11))",
          },
          width: 298.1,
          height: 96.9,
        }}
      >
        Facebook
      </Button>
      <Button
        className="h-[96.9px] w-[329.1px]"
        disableElevation={true}
        variant="contained"
        sx={{
          textTransform: "none",
          color: "#fff",
          fontSize: "47.2",
          background:
            "linear-gradient(174.61deg, rgba(255, 255, 255, 0.11), rgba(58, 58, 58, 0.11))",
          border: "#a9a9a9 solid 1.1px",
          borderRadius: "56.03589630126953px",
          "&:hover": {
            background:
              "linear-gradient(174.61deg, rgba(255, 255, 255, 0.11), rgba(58, 58, 58, 0.11))",
          },
          width: 329.1,
          height: 96.9,
        }}
      >
        Instragram
      </Button>
      <div className="w-[234px] rounded-[56.04px] [background:linear-gradient(174.61deg,_rgba(255,_255,_255,_0.11),_rgba(58,_58,_58,_0.11))] box-border overflow-hidden shrink-0 flex flex-row items-start justify-center py-[18px] px-5 [transform:_rotate(180deg)] border-[1.1px] border-solid border-darkgray-100">
        <div className="w-[42px] relative font-light flex items-center mq450:text-9xl mq800:text-19xl">
          IU
        </div>
      </div>
      <div className="h-[96.9px] w-[338.1px] rounded-[56.04px] [background:linear-gradient(174.61deg,_rgba(255,_255,_255,_0.11),_rgba(58,_58,_58,_0.11))] box-border overflow-hidden shrink-0 flex flex-row items-start justify-start pt-[19.4px] pb-[19.5px] pr-[38px] pl-10 whitespace-nowrap border-[1.1px] border-solid border-darkgray-100">
        <div className="self-stretch flex-1 relative font-light flex items-center">
          Millet Foods
        </div>
      </div>
    </div>
  );
};

CompanyItemsTwo.propTypes = {
  className: PropTypes.string,
};

export default CompanyItemsTwo;
