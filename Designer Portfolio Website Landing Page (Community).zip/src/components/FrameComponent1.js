const FrameComponent1 = ({ className = "" }) => {
  return (
    <section
      className={`w-[1426px] flex flex-row items-start justify-center pt-0 px-5 pb-[93.9px] box-border max-w-full text-left text-39xl-3 text-glass font-clash-display mq800:pb-[61px] mq800:box-border ${className}`}
    >
      <div className="w-[1260px] flex flex-col items-start justify-start gap-[59px] max-w-full mq800:gap-[29px]">
        <div className="w-[282px] flex flex-col items-start justify-start gap-[10px]">
          <div className="flex flex-row items-start justify-start py-0 pr-0 pl-0.5">
            <div
              className="relative leading-[53px] font-semibold z-[4] mq450:text-16xl mq450:leading-[32px] mq800:text-28xl mq800:leading-[42px]"
              data-scroll-to="aboutMeText"
            >
              About Me
            </div>
          </div>
          <img
            className="self-stretch h-0.5 relative max-w-full overflow-hidden shrink-0 z-[4]"
            loading="lazy"
            alt=""
            src="/group-8.svg"
          />
        </div>
        <div className="self-stretch flex flex-row items-start justify-start py-0 pr-0 pl-0.5 box-border max-w-full text-justify text-21xl-5">
          <div className="flex-1 flex flex-row items-start justify-start gap-[78px] max-w-full mq450:gap-[19px] mq800:gap-[39px] mq1125:flex-wrap">
            <div className="w-[355px] flex flex-row items-start justify-start relative min-w-[355px] max-w-full mq450:min-w-full mq1125:flex-1">
              <div className="h-[87px] w-[403px] absolute !m-[0] right-[-21px] bottom-[90.39px] rounded-[50%] box-border [transform:_rotate(-15.3deg)] [transform-origin:0_0] z-[4] border-[0px] border-solid border-glass" />
              <div className="h-[87px] w-[403px] absolute !m-[0] top-[225.91px] left-[-46.9px] rounded-[50%] box-border [transform:_rotate(-15.3deg)] [transform-origin:0_0] z-[5] border-[0px] border-solid border-glass" />
              <div className="h-[87px] w-[403px] absolute !m-[0] top-[160.01px] left-[-57.7px] rounded-[50%] box-border [transform:_rotate(-15.3deg)] [transform-origin:0_0] z-[6] border-[0px] border-solid border-glass" />
              <img
                className="h-[467px] flex-1 relative max-w-full overflow-hidden object-cover z-[7] mq1125:flex-1"
                alt=""
                src="/f5dd1984f3a1cd0e18e26dace46c677csticker-1@2x.png"
              />
              <img
                className="h-[61px] w-[61px] absolute !m-[0] top-[0px] right-[26px] z-[8]"
                alt=""
                src="/star-1.svg"
              />
              <img
                className="h-[23px] w-[23px] absolute !m-[0] top-[-11px] right-[15px] z-[9]"
                loading="lazy"
                alt=""
                src="/star-2.svg"
              />
            </div>
            <div className="flex-1 flex flex-col items-start justify-start pt-[59px] px-0 pb-0 box-border min-w-[536px] max-w-full mq450:pt-[38px] mq450:box-border mq800:min-w-full">
              <p className="m-0 self-stretch relative z-[4] mq450:text-5xl mq800:text-13xl">
                Hey there! I'm Muzamil, a passionate UI/UX designer armed with
                creativity and a love for problem-solving. With a blend of
                design thinking and user-centric approach, I'm on a mission to
                create digital experiences that leave a lasting impression. So
                let's collaborate and bring your vision to life!
              </p>
            </div>
          </div>
        </div>
      </div>
    </section>
  );
};

FrameComponent1.propTypes = {
  className: PropTypes.string,
};

export default FrameComponent1;
