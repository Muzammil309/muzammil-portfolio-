import Navigation1 from "./Navigation1";
import Introduction from "./Introduction";
import FrameComponent1 from "./FrameComponent1";
import FrameComponent from "./FrameComponent";
import CompanyListOne from "./CompanyListOne";
import CompanyItemsTwo from "./CompanyItemsTwo";
import Footer from "./Footer";
import PropTypes from "prop-types";

const PortfolioDesktop = ({ className = "" }) => {
  return (
    <main
      className={`flex-1 bg-black flex flex-col items-end justify-start pt-[45px] px-0 pb-[69.8px] box-border relative gap-[48.1px] max-w-full text-left text-39xl-3 text-glass font-clash-display mq800:gap-[24px] mq1125:pb-5 mq1125:box-border mq1350:pt-5 mq1350:pb-[29px] mq1350:box-border ${className}`}
    >
      <img
        className="w-[3553.7px] h-[2895px] absolute !m-[0] bottom-[567.4px] left-[-1551.7px] object-contain"
        alt=""
        src="/contacts@2x.png"
      />
      <div className="w-[601px] h-[601px] absolute !m-[0] top-[-275px] right-[-289px] rounded-[50%] bg-mediumslateblue z-[2]" />
      <section className="w-full h-[5880px] absolute !m-[0] right-[0px] bottom-[-655px] left-[0px] [backdrop-filter:blur(280px)] bg-darkslategray z-[3]" />
      <Navigation1 />
      <div className="w-[566px] !m-[0] absolute top-[173px] left-[823px] flex flex-row items-start justify-start max-w-full">
        <div className="h-[601px] w-[601px] absolute !m-[0] top-[-125px] left-[-223px] rounded-[50%] bg-khaki" />
        <img
          className="h-[566px] flex-1 relative max-w-full overflow-hidden object-cover z-[5]"
          loading="lazy"
          alt=""
          src="/be7c217eaea29db43ae2d6de19f2b2edsticker-1@2x.png"
        />
      </div>
      <Introduction />
      <img
        className="w-[1521.5px] h-[174.6px] !m-[0] absolute top-[839px] right-[-61px] object-contain z-[4]"
        alt=""
        src="/empty@2x.png"
      />
      <FrameComponent1 />
      <section className="self-stretch flex flex-row items-start justify-center pt-0 pb-[133.9px] pr-5 pl-[21px] box-border max-w-full text-center text-101xl-1 text-darkgray-200 font-clash-display mq450:pb-[87px] mq450:box-border">
        <div className="w-[1264px] flex flex-row items-start justify-between gap-[20px] max-w-full z-[4] mq1125:flex-wrap mq1125:justify-center">
          <div className="w-[253px] flex flex-col items-start justify-start gap-[11.3px]">
            <div className="self-stretch flex flex-row items-start justify-start py-0 px-[13px]">
              <div className="flex-1 flex flex-row items-start justify-start">
                <b className="flex-1 relative leading-[121.7px] text-transparent !bg-clip-text [background:linear-gradient(107.79deg,_rgba(152,_28,_130,_0.5),_rgba(237,_109,_101,_0.5)_55.5%,_rgba(176,_121,_0,_0.5))] [-webkit-background-clip:text] [-webkit-text-fill-color:transparent] [filter:blur(15px)] mq450:text-11xl mq450:leading-[49px] mq800:text-29xl mq800:leading-[73px]">
                  5+
                </b>
                <b className="flex-1 relative leading-[121.7px] text-transparent !bg-clip-text [background:linear-gradient(107.79deg,_#981c82,_#ed6d65_55.5%,_#b07900)] [-webkit-background-clip:text] [-webkit-text-fill-color:transparent] z-[1] ml-[-227px] mq450:text-11xl mq450:leading-[49px] mq800:text-29xl mq800:leading-[73px]">
                  5+
                </b>
              </div>
            </div>
            <div className="self-stretch h-[114px] relative text-12xl-2 font-medium flex items-center justify-center mq450:text-lgi mq800:text-6xl">
              Months of Design Experience
            </div>
          </div>
          <div className="h-[226px] w-0.5 relative box-border border-r-[2px] border-solid border-dimgray mq1125:w-full mq1125:h-0.5" />
          <div className="w-60 flex flex-col items-start justify-start relative gap-[30px]">
            <b className="self-stretch relative leading-[122px] text-transparent !bg-clip-text [background:linear-gradient(107.79deg,_rgba(152,_28,_130,_0.5),_rgba(237,_109,_101,_0.5)_55.5%,_rgba(176,_121,_0,_0.5))] [-webkit-background-clip:text] [-webkit-text-fill-color:transparent] [filter:blur(15px)] mq450:text-11xl mq450:leading-[49px] mq800:text-29xl mq800:leading-[73px]">
              20+
            </b>
            <div className="flex flex-row items-start justify-start py-0 pr-4 pl-[13px] text-12xl-2">
              <div className="w-[211px] relative font-medium inline-block mq450:text-lgi mq800:text-6xl">
                <p className="m-0">{`Overall Global `}</p>
                <p className="m-0">Customers</p>
              </div>
            </div>
            <b className="w-full absolute !m-[0] top-[0px] left-[0px] leading-[122px] flex text-transparent !bg-clip-text [background:linear-gradient(107.79deg,_#981c82,_#ed6d65_55.5%,_#b07900)] [-webkit-background-clip:text] [-webkit-text-fill-color:transparent] items-center justify-center z-[1] mq450:text-11xl mq450:leading-[49px] mq800:text-29xl mq800:leading-[73px]">
              20+
            </b>
          </div>
          <div className="h-[226px] w-0.5 relative box-border border-r-[2px] border-solid border-dimgray mq1125:w-full mq1125:h-0.5" />
          <div className="w-[243px] flex flex-col items-end justify-start relative gap-[30px]">
            <b className="self-stretch relative leading-[122px] text-transparent !bg-clip-text [background:linear-gradient(107.79deg,_rgba(152,_28,_130,_0.5),_rgba(237,_109,_101,_0.5)_55.5%,_rgba(176,_121,_0,_0.5))] [-webkit-background-clip:text] [-webkit-text-fill-color:transparent] [filter:blur(15px)] mq450:text-11xl mq450:leading-[49px] mq800:text-29xl mq800:leading-[73px]">
              20+
            </b>
            <div className="w-[228px] relative text-12xl-2 font-medium inline-block mq450:text-lgi mq800:text-6xl">
              <p className="m-0">{`Projects I Have `}</p>
              <p className="m-0">Worked on</p>
            </div>
            <b className="w-full absolute !m-[0] top-[0px] left-[0px] leading-[122px] flex text-transparent !bg-clip-text [background:linear-gradient(107.79deg,_#981c82,_#ed6d65_55.5%,_#b07900)] [-webkit-background-clip:text] [-webkit-text-fill-color:transparent] items-center justify-center z-[1] mq450:text-11xl mq450:leading-[49px] mq800:text-29xl mq800:leading-[73px]">
              20+
            </b>
          </div>
        </div>
      </section>
      <FrameComponent />
      <div className="self-stretch flex flex-row items-start justify-center pt-0 pb-[12.9px] pr-[377px] pl-5 box-border max-w-full mq450:pr-5 mq450:box-border mq800:pr-[94px] mq800:box-border mq1350:pr-[188px] mq1350:box-border">
        <div className="w-[897px] flex flex-col items-start justify-start gap-[10px] max-w-full">
          <b className="self-stretch relative leading-[53px] z-[4] mq450:text-16xl mq450:leading-[32px] mq800:text-28xl mq800:leading-[42px]">
            Companies I’ve Worked With
          </b>
          <div className="w-[876px] flex flex-row items-start justify-start py-0 px-1 box-border max-w-full">
            <img
              className="flex-1 relative max-w-full overflow-hidden max-h-full z-[4]"
              loading="lazy"
              alt=""
              src="/group-10.svg"
            />
          </div>
        </div>
      </div>
      <CompanyListOne />
      <section className="flex flex-col items-start justify-start py-0 pr-0 pl-[30px] box-border gap-[10.1px] max-w-full text-left text-28xl-2 text-glass font-clash-display">
        <CompanyItemsTwo />
        <Footer />
      </section>
    </main>
  );
};

PortfolioDesktop.propTypes = {
  className: PropTypes.string,
};

export default PortfolioDesktop;
