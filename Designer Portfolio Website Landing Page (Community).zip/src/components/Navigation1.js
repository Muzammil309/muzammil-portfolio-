import { useCallback } from "react";
import Resume from "./Resume";
import PropTypes from "prop-types";

const Navigation1 = ({ className = "" }) => {
  const onHomeTextClick = useCallback(() => {
    const anchor = document.querySelector("[data-scroll-to='muzammilText']");
    if (anchor) {
      anchor.scrollIntoView({ block: "start", behavior: "smooth" });
    }
  }, []);

  const onAboutTextClick = useCallback(() => {
    const anchor = document.querySelector("[data-scroll-to='aboutMeText']");
    if (anchor) {
      anchor.scrollIntoView({ block: "start", behavior: "smooth" });
    }
  }, []);

  const onWorkTextClick = useCallback(() => {
    const anchor = document.querySelector("[data-scroll-to='projectsText']");
    if (anchor) {
      anchor.scrollIntoView({ block: "start", behavior: "smooth" });
    }
  }, []);

  const onContactTextClick = useCallback(() => {
    const anchor = document.querySelector("[data-scroll-to='groupContainer']");
    if (anchor) {
      anchor.scrollIntoView({ block: "start", behavior: "smooth" });
    }
  }, []);

  const onGroupContainerClick = useCallback(() => {
    // Please sync "Resume" to the project
  }, []);

  return (
    <header
      className={`self-stretch flex flex-row items-start justify-start pt-0 px-[37px] pb-[72.9px] box-border top-[0] z-[99] sticky max-w-full text-center text-6xl-5 text-glass font-clash-display ${className}`}
    >
      <div className="w-[1339px] flex flex-row items-end justify-between gap-[20px] max-w-full z-[4] mq800:w-[889px]">
        <div className="w-[99px] flex flex-col items-start justify-end pt-0 px-0 pb-[4.7px] box-border">
          <img
            className="self-stretch h-[22.5px] relative max-w-full overflow-hidden shrink-0"
            loading="lazy"
            alt=""
            src="/logo.svg"
          />
        </div>
        <nav className="m-0 w-[450px] flex flex-row items-start justify-start gap-[39px] max-w-full text-left text-6xl text-glass font-clash-display mq450:gap-[19px] mq800:hidden">
          <a
            className="[text-decoration:none] relative text-[inherit] inline-block min-w-[77px] cursor-pointer"
            onClick={onHomeTextClick}
          >
            Home
          </a>
          <a
            className="[text-decoration:none] relative text-[inherit] inline-block min-w-[77px] cursor-pointer"
            onClick={onAboutTextClick}
          >
            About
          </a>
          <a
            className="[text-decoration:none] relative text-[inherit] inline-block min-w-[77px] cursor-pointer"
            onClick={onWorkTextClick}
          >
            Work
          </a>
          <a
            className="[text-decoration:none] w-[102px] relative text-[inherit] inline-block shrink-0 min-w-[102px] cursor-pointer"
            onClick={onContactTextClick}
          >
            Contact
          </a>
        </nav>
        <div className="w-36 flex flex-col items-start justify-end pt-0 px-0 pb-[5.5px] box-border">
          <div
            className="self-stretch flex flex-row items-start justify-start gap-[3px] cursor-pointer"
            onClick={onGroupContainerClick}
          >
            <Resume />
            <div className="flex flex-col items-start justify-start pt-px px-0 pb-0">
              <div className="w-[18px] h-[18px] relative">
                <img
                  className="absolute top-[0px] left-[0px] w-full h-full"
                  alt=""
                  src="/group-3.svg"
                />
                <img
                  className="absolute top-[0px] left-[0px] w-full h-full z-[1]"
                  loading="lazy"
                  alt=""
                  src="/group-4.svg"
                />
              </div>
            </div>
          </div>
        </div>
      </div>
    </header>
  );
};

Navigation1.propTypes = {
  className: PropTypes.string,
};

export default Navigation1;
