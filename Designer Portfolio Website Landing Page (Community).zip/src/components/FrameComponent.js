const FrameComponent = ({ className = "" }) => {
  return (
    <section
      className={`self-stretch flex flex-row items-start justify-center pt-0 pb-[87.9px] pr-[23px] pl-5 box-border max-w-full text-left text-39xl-3 text-glass font-clash-display mq450:pb-6 mq450:box-border mq1125:pb-[37px] mq1125:box-border mq1350:pb-[57px] mq1350:box-border ${className}`}
    >
      <div className="w-[1243px] flex flex-col items-start justify-start gap-[87px] max-w-full mq450:gap-[22px] mq800:gap-[43px]">
        <div className="w-[286px] flex flex-col items-start justify-start gap-[10px]">
          <div className="self-stretch flex flex-row items-start justify-start py-0 pr-0 pl-1.5">
            <div
              className="flex-1 relative leading-[53px] font-semibold z-[4] mq450:text-16xl mq450:leading-[32px] mq800:text-28xl mq800:leading-[42px]"
              data-scroll-to="projectsText"
            >
              Projects
            </div>
          </div>
          <img
            className="w-[263px] h-0.5 relative z-[4]"
            loading="lazy"
            alt=""
            src="/group-9.svg"
          />
        </div>
        <div className="self-stretch flex flex-row items-start justify-start py-0 pr-0 pl-0.5 box-border max-w-full">
          <div className="flex-1 flex flex-col items-start justify-start gap-[25px] max-w-full">
            <div className="self-stretch flex flex-row flex-wrap items-start justify-start gap-[37px] max-w-full mq800:gap-[18px]">
              <img
                className="self-stretch flex-1 relative rounded-22xl max-w-full overflow-hidden max-h-full object-cover min-w-[391px] min-h-[452px] z-[4] mq800:min-w-full"
                loading="lazy"
                alt=""
                src="/rectangle-7@2x.png"
              />
              <img
                className="self-stretch flex-1 relative rounded-22xl max-w-full overflow-hidden max-h-full object-cover min-w-[391px] min-h-[452px] z-[4] mq800:min-w-full"
                loading="lazy"
                alt=""
                src="/rectangle-8@2x.png"
              />
            </div>
            <img
              className="self-stretch relative rounded-22xl max-w-full overflow-hidden max-h-full object-cover z-[4]"
              loading="lazy"
              alt=""
              src="/rectangle-11@2x.png"
            />
            <div className="self-stretch flex flex-row flex-wrap items-start justify-start gap-[37px] max-w-full mq800:gap-[18px]">
              <img
                className="self-stretch flex-1 relative rounded-2xs max-w-full overflow-hidden max-h-full object-cover min-w-[391px] min-h-[452px] z-[4] mq800:min-w-full"
                loading="lazy"
                alt=""
                src="/rectangle-9@2x.png"
              />
              <img
                className="self-stretch flex-1 relative rounded-22xl max-w-full overflow-hidden max-h-full object-cover min-w-[391px] min-h-[452px] z-[4] mq800:min-w-full"
                loading="lazy"
                alt=""
                src="/rectangle-10@2x.png"
              />
            </div>
          </div>
        </div>
      </div>
    </section>
  );
};

FrameComponent.propTypes = {
  className: PropTypes.string,
};

export default FrameComponent;
