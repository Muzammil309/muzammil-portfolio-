const Resume = ({ className = "" }) => {
  return (
    <a
      className={`[text-decoration:none] h-[21px] flex-1 relative text-6xl-5 font-semibold font-clash-display text-glass text-center flex items-center justify-center [text-shadow:0px_0px_4px_rgba(255,_255,_255,_0.42)] whitespace-nowrap ${className}`}
    >
      Resume
    </a>
  );
};

Resume.propTypes = {
  className: PropTypes.string,
};

export default Resume;
