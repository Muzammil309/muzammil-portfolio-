const Introduction = ({ className = "" }) => {
  return (
    <section
      className={`w-[1365px] flex flex-row items-start justify-start pt-0 pb-[162.9px] pr-0 pl-5 box-border gap-[7px] max-w-full text-left text-67xl-3 text-glass font-clash-display mq450:pb-[69px] mq450:box-border mq1125:pb-[106px] mq1125:box-border mq1350:flex-wrap ${className}`}
    >
      <div className="w-[890px] flex flex-col items-start justify-start relative gap-[71px] min-w-[890px] shrink-0 [debug_commit:bf4bc93] max-w-full mq450:gap-[18px] mq1125:gap-[35px] mq1125:min-w-full mq1350:flex-1">
        <div className="self-stretch flex flex-col items-start justify-start gap-[44px] max-w-full mq450:gap-[22px]">
          <div className="self-stretch flex flex-row items-start justify-start relative max-w-full">
            <b
              className="flex-1 relative inline-block max-w-full z-[4] mq450:text-7xl mq800:text-24xl"
              data-scroll-to="muzammilText"
            >
              <p className="m-0">Muzamil</p>
              <p className="m-0">Ahmed Khan</p>
            </b>
            <div className="w-[91px] absolute !m-[0] top-[-61px] left-[-44px] text-60xl-9 font-abel text-orange inline-block z-[5] mq450:text-29xl mq800:text-45xl">
              I’m
            </div>
          </div>
          <div className="w-[735px] flex flex-row items-start justify-start py-0 px-0.5 box-border max-w-full text-18xl">
            <p className="m-0 flex-1 relative font-light inline-block max-w-full z-[4] mq450:text-3xl mq800:text-11xl">
              An aspiring UI/UX Designer. Who breathes life into pixels,
              crafting interfaces that not only engage but enchant.
            </p>
          </div>
        </div>
        <div className="w-[514.9px] flex flex-row items-start justify-start py-0 px-[46px] box-border max-w-full text-center text-14xl-2 mq800:pl-[23px] mq800:pr-[23px] mq800:box-border">
          <div className="flex-1 flex flex-row items-start justify-between max-w-full gap-[20px] mq450:flex-wrap">
            <div className="w-[152.9px] flex flex-row items-start justify-start relative">
              <div className="h-[77px] w-60 absolute !m-[0] bottom-[-20px] left-[-44px] rounded-[17.26px] [background:linear-gradient(174.61deg,_rgba(255,_255,_255,_0.5),_rgba(58,_58,_58,_0.5))] box-border z-[4] border-[1.2px] border-solid border-stroke-button" />
              <div className="flex-1 relative shrink-0 [debug_commit:bf4bc93] z-[5] mq450:text-xl mq800:text-8xl">
                Hire Me
              </div>
              <div className="w-[54px] absolute !m-[0] top-[-45.96px] right-[-49.2px] text-34xl-3 text-left inline-block [transform:_rotate(-13.8deg)] [transform-origin:0_0] z-[6] mq450:text-13xl mq800:text-24xl">
                💼
              </div>
            </div>
            <div className="w-[152.9px] flex flex-row items-start justify-start relative">
              <div className="h-[77px] w-60 absolute !m-[0] bottom-[-20px] left-[-44px] rounded-[17.26px] [background:linear-gradient(174.61deg,_rgba(255,_255,_255,_0.5),_rgba(58,_58,_58,_0.5))] box-border z-[4] border-[1.2px] border-solid border-stroke-button" />
              <div className="flex-1 relative shrink-0 [debug_commit:bf4bc93] z-[5] mq450:text-xl mq800:text-8xl">
                My Story
              </div>
            </div>
          </div>
        </div>
        <div className="absolute !m-[0] right-[359.9px] bottom-[-38.19px] text-34xl-3 [transform:_rotate(-3.1deg)] [transform-origin:0_0] z-[5] mq450:text-13xl mq800:text-24xl">
          🎤
        </div>
      </div>
      <div className="h-[707px] w-[601px] flex flex-col items-start justify-start pt-[106px] px-0 pb-0 box-border min-w-[601px] max-w-full shrink-0 mq800:pt-[69px] mq800:box-border mq800:min-w-full mq1350:flex-1">
        <div className="self-stretch flex-1 relative rounded-[50%] bg-orangered shrink-0 [debug_commit:bf4bc93] z-[1]" />
      </div>
    </section>
  );
};

Introduction.propTypes = {
  className: PropTypes.string,
};

export default Introduction;
