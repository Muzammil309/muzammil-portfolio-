/** @type {import('tailwindcss').Config} */
module.exports = {
  content: ["./src/**/*.{js,jsx,ts,tsx}"],
  theme: {
    extend: {
      colors: {
        black: "#000",
        glass: "#fff",
        darkgray: {
          "100": "#a9a9a9",
          "200": "#9f9f9f",
        },
        dimgray: "#585858",
        orangered: "rgba(255, 93, 32, 0.66)",
        "stroke-button": "#444",
        orange: "#ffa620",
        khaki: "rgba(244, 235, 151, 0.66)",
        darkslategray: "rgba(46, 46, 46, 0.45)",
        mediumslateblue: "rgba(91, 108, 255, 0.66)",
      },
      spacing: {},
      fontFamily: {
        "clash-display": "'Clash Display'",
        abel: "Abel",
      },
      borderRadius: {
        "6xl": "25px",
        "37xl": "56px",
        "22xl": "41px",
        "2xs": "11px",
        "mid-3": "17.3px",
      },
    },
    fontSize: {
      "smi-6": "12.6px",
      "12xl-5": "31.5px",
      lgi: "19px",
      "6xl": "25px",
      "28xl-2": "47.2px",
      "9xl": "28px",
      "19xl": "38px",
      "39xl-3": "58.3px",
      "16xl": "35px",
      "28xl": "47px",
      "101xl-1": "120.1px",
      "11xl": "30px",
      "29xl": "48px",
      "12xl-2": "31.2px",
      "21xl-5": "40.5px",
      "5xl": "24px",
      "13xl": "32px",
      "34xl-3": "53.3px",
      "24xl": "43px",
      "14xl-2": "33.2px",
      xl: "20px",
      "8xl": "27px",
      "18xl": "37px",
      "3xl": "22px",
      "60xl-9": "79.9px",
      "45xl": "64px",
      "67xl-3": "86.3px",
      "7xl": "26px",
      "6xl-5": "25.5px",
      inherit: "inherit",
    },
    screens: {
      mq1350: {
        raw: "screen and (max-width: 1350px)",
      },
      mq1125: {
        raw: "screen and (max-width: 1125px)",
      },
      mq800: {
        raw: "screen and (max-width: 800px)",
      },
      mq450: {
        raw: "screen and (max-width: 450px)",
      },
    },
  },
  corePlugins: {
    preflight: false,
  },
};
